from django.contrib import admin
from .models import KeyValue

admin.site.register(KeyValue)
