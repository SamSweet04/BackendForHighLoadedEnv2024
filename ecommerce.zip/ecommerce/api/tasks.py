from celery import shared_task
from .models import Order
from django.core.mail import EmailMessage
from django.conf import settings
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas



def generate_invoice_pdf(order):
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)

    # Заголовок счета
    c.drawString(100, 750, f"Invoice for Order {order.id}")

    # Информация о заказе
    c.drawString(100, 700, f"Product: {order.product.name}")
    c.drawString(100, 675, f"Quantity: {order.quantity}")
    c.drawString(100, 650, f"Total Price: ${order.total_price}")

    # Дополнительные данные можно добавить здесь

    c.showPage()
    c.save()

    buffer.seek(0)
    return buffer


# Асинхронная задача для обработки заказа
@shared_task
def process_order(order_id):
    order = Order.objects.get(id=order_id)

    # Генерация PDF счета
    pdf_buffer = generate_invoice_pdf(order)

    # Настройка письма
    subject = f"Invoice for Order {order.id}"
    body = f"Dear {order.user.username},\n\nPlease find attached the invoice for your recent order."
    email = EmailMessage(subject, body, settings.DEFAULT_FROM_EMAIL, [order.user.email])

    # Прикрепляем PDF счет к письму
    email.attach(f"invoice_{order.id}.pdf", pdf_buffer.getvalue(), "application/pdf")

    # Отправляем письмо
    email.send()

    print(f"Order {order.id} processed and email sent to {order.user.email}")
